(function () {
  const L = {
    none: "\u65e0",
    wallet: "\u94b1\u5305",
    copied: "\u5df2\u590d\u5236",
    copy: "\u590d\u5236",
    copyCa: "\u70b9\u51fb\u590d\u5236CA",
    dismiss: "\u79fb\u9664",
    title: "CA \u6346\u7ed1\u5206\u6790",
    token: "\u4ee3\u5e01",
    mcapLp: "\u5e02\u503c/\u6c60\u5b50",
    chips: "\u7b79\u7801\u96c6\u4e2d",
    topProfit: "Top\u76c8\u5229",
    unsold: "\u672a\u5356\u51fa",
    summaryTitle: "\u5206\u7c7b\u6458\u8981\uff1a\u5360\u6bd4 / \u5e73\u5747\u76c8\u5229",
    walletDetails: "\u5bf9\u5e94\u6346\u7ed1\u94b1\u5305\u8be6\u60c5",
    bundleTimeDetails: "\u6346\u7ed1\u65f6\u95f4\u7c07\u8be6\u60c5",
    buyTimeDetails: "\u8d2d\u4e70\u65f6\u95f4\u7c07\u8be6\u60c5",
    riskTitle: "\u53ef\u89c2\u5bdf\u98ce\u9669\u56e0\u7d20",
    bottomChipTitle: "\u5e95\u90e8\u7b79\u7801\u5356\u51fa\u89c2\u5bdf",
    noSummary: "\u6682\u65e0\u5206\u7c7b\u6458\u8981",
    noBottomChips: "\u6682\u65e0\u53ef\u8bc6\u522b\u7684\u5e95\u90e8\u6210\u672c\u7b79\u7801",
    noBundlers: "\u672a\u547d\u4e2d\u672c\u5730\u6346\u7ed1\u6807\u7b7e\u6216 GMGN bundler \u6807\u7b7e",
    noCreateSecond: "\u6ca1\u6709\u540c\u79d2\u521b\u5efa\u7c07",
    noCreateHour: "\u6ca1\u6709\u660e\u663e\u5c0f\u65f6\u7ea7\u521b\u5efa\u7c07",
    noBuySecond: "\u6ca1\u6709\u540c\u79d2\u8d2d\u4e70\u7c07",
    noBuyFive: "\u6ca1\u6709\u660e\u663e 5 \u5206\u949f\u8d2d\u4e70\u7c07",
    noRisk: "\u6682\u65e0\u660e\u663e\u98ce\u9669\u6807\u7b7e",
    openHint: "\u6253\u5f00 GMGN \u4ee3\u5e01\u9875\uff0c\u6216\u624b\u52a8\u8f93\u5165 CA\u3002",
    refresh: "\u5237\u65b0",
    clear: "\u6e05\u7a7a",
    caView: "CA\u5206\u6790",
    abnormalView: "\u5f02\u52a8\u68c0\u6d4b",
    newTokenView: "\u6253\u65b0\u7b56\u7565\u5e01",
    watchView: "\u5f02\u52a8\u76d1\u63a7",
    abnormalTitle: "\u5e95\u90e8\u5f02\u52a8\u4ee3\u5e01",
    abnormalHint: "\u70b9\u51fb\u4ee3\u5e01\u590d\u5236 CA",
    abnormalEmpty: "\u6682\u65e0\u5f02\u52a8\u4ee3\u5e01\u6570\u636e",
    newTokenTitle: "\u6253\u65b0\u7b56\u7565\u5e01",
    newTokenHint: "Deep Alpha 1m \u6253\u65b0\u63a8\u9001",
    newTokenEmpty: "\u6682\u65e0 1m \u6253\u65b0\u7b56\u7565\u5e01\u6570\u636e",
    pushTime: "\u63a8\u9001\u65f6\u95f4",
    feeSol: "\u624b\u7eed\u8d39",
    buyScore: "\u4e70\u5206",
    repeat: "\u590d\u63a8",
    currentMcap: "\u5f53\u524d\u5e02\u503c",
    firstAbnormalMcap: "\u9996\u6b21\u5f02\u52a8\u5e02\u503c",
    firstAbnormalTime: "\u9996\u6b21\u5f02\u52a8\u65f6\u95f4",
    firstGain: "\u76f8\u5bf9\u9996\u6b21\u6da8\u5e45",
    maxMcap: "\u6700\u9ad8\u5e02\u503c",
    liquidity: "\u6d41\u52a8\u6027",
    poolMcapRatio: "\u6c60\u5b50/\u5e02\u503c",
    poolVeryBad: "\u975e\u5e38\u5dee",
    poolNormal: "\u6b63\u5e38",
    poolGood: "\u826f\u597d",
    poolGreat: "\u975e\u5e38\u597d",
    priceChange: "\u6da8\u5e45",
    signalType: "\u4fe1\u53f7",
    strategyProfile: "\u7b56\u7565",
    strategyWatch: "\u89c2\u5bdf",
    avoidReason: "\u98ce\u9669\u539f\u56e0",
    narrativeCategory: "\u53d9\u4e8b\u7c7b\u578b",
    abnormalHistory: "\u5386\u53f2\u6da8\u5e45",
    topHoldChange: "Top\u6301\u4ed3\u53d8\u5316",
    watchlistLowMcap: "\u91cd\u70b9\u4f4e\u5e02\u503c",
    watchlistMcap: "\u89c2\u5bdf\u5e02\u503c",
    tokenAge: "\u5e01\u9f84",
    bundleControl: "\u63a7\u76d8",
    bundleTagged: "\u6807\u8bb0\u6346\u7ed1",
    bundleSource: "\u540c\u6e90",
    bundleGmgn: "GMGN\u6346\u7ed1",
    ratTrader: "\u8001\u9f20\u4ed3",
    top10: "Top10",
    updated: "\u66f4\u65b0",
    collapse: "\u6536\u8d77",
    analyze: "\u5206\u6790",
    run: "\u67e5",
    analyzing: "\u6b63\u5728\u5206\u6790",
    noValidCa: "\u6ca1\u6709\u8bc6\u522b\u5230\u6709\u6548 CA\u3002",
    apiError: "\u672c\u5730\u63a5\u53e3\u4e0d\u53ef\u7528\u6216\u5206\u6790\u5931\u8d25",
    walletCount: "\u94b1\u5305\u6570",
    holdPct: "\u6301\u4ed3\u5360\u6bd4",
    buyVolume: "\u4e70\u5165\u989d",
    profitable: "\u76c8\u5229\u94b1\u5305",
    realized: "\u5df2\u5b9e\u73b0",
    unrealized: "\u672a\u5b9e\u73b0",
    buy: "\u4e70\u5165",
    holding: "\u6301\u4ed3",
    profit: "\u76c8\u5229",
    highSell: "\u9ad8\u5356\u51fa",
    sellProgress: "\u5356\u51fa\u8fdb\u5ea6",
    remainingHolding: "\u5269\u4f59\u6301\u4ed3",
    sold: "\u5df2\u5356",
  };
  const POS_KEY = "ca_cluster_panel_position_v1";
  const LAYOUT_KEY = "ca_cluster_panel_layout_v2";
  const PLUGIN_EVENT_LAST_ID_KEY = "ca_cluster_plugin_event_last_id_v1";
  const PLUGIN_EVENT_FALLBACK_MS = 5000;
  const DEFAULT_WIDTH = 336;
  const DEFAULT_HEIGHT = 520;
  const MIN_WIDTH = 280;
  const MIN_HEIGHT = 220;
  const STATE = {
    ca: "",
    loading: false,
    collapsed: false,
    result: null,
    error: "",
    copied: "",
    dragging: false,
    resizing: false,
    view: "abnormal",
    abnormalLoading: false,
    abnormalItems: [],
    abnormalError: "",
    abnormalTimer: 0,
    abnormalLastCount: 0,
    abnormalRequestId: 0,
    alphaLoading: false,
    alphaItems: [],
    alphaError: "",
    alphaTimer: 0,
    alphaRequestId: 0,
    pluginEventSource: null,
    pluginEventReady: false,
    pluginEventFallbackTimer: 0,
    pluginEventLastSignalAt: 0,
    pluginEventLastId: "",
    dismissedSignals: {},
    serviceMode: "local",
    serviceBaseUrl: "",
  };

  function fmtPct(value) {
    const n = Number(value || 0);
    return `${n.toFixed(n >= 10 ? 1 : 2)}%`;
  }

  function poolMcapRatioPct(value) {
    const n = Number(value || 0);
    if (!Number.isFinite(n) || n <= 0) return 0;
    return n > 1 ? n : n * 100;
  }

  function poolMcapRatioStatus(value) {
    const pct = poolMcapRatioPct(value);
    if (pct <= 0) return { pct, label: L.none, cls: "ca-pool-unknown" };
    if (pct < 5) return { pct, label: L.poolVeryBad, cls: "ca-pool-bad" };
    if (pct < 10) return { pct, label: L.poolNormal, cls: "ca-pool-normal" };
    if (pct <= 15) return { pct, label: L.poolGood, cls: "ca-pool-good" };
    return { pct, label: L.poolGreat, cls: "ca-pool-great" };
  }

  function renderPoolMcapRatio(value) {
    const status = poolMcapRatioStatus(value);
    if (status.pct <= 0) return `<span class="ca-pool-ratio ca-pool-unknown">${L.none}</span>`;
    return `<span class="ca-pool-ratio ${status.cls}"><strong>${status.pct.toFixed(status.pct >= 10 ? 1 : 2)}%</strong><small>${status.label}</small></span>`;
  }

  function fmtSignedPct(value) {
    const n = Number(value || 0);
    if (!Number.isFinite(n)) return "0.00%";
    const sign = n > 0 ? "+" : "";
    return `${sign}${n.toFixed(Math.abs(n) >= 10 ? 1 : 2)}%`;
  }

  function fmtUsd(value) {
    const n = Number(value || 0);
    if (!Number.isFinite(n) || n === 0) return "$0";
    const sign = n < 0 ? "-" : "";
    const abs = Math.abs(n);
    if (abs >= 1_000_000) return `${sign}$${(abs / 1_000_000).toFixed(2)}M`;
    if (abs >= 1_000) return `${sign}$${(abs / 1_000).toFixed(1)}K`;
    return `${sign}$${abs.toFixed(0)}`;
  }

  function fmtTime(value) {
    if (!value) return "-";
    const raw = Number(value);
    const date = Number.isFinite(raw) ? new Date(raw < 1000000000000 ? raw * 1000 : raw) : new Date(value);
    if (!Number.isFinite(date.getTime())) return "-";
    return date.toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
  }

  function fmtAge(seconds) {
    const value = Number(seconds || 0);
    if (!Number.isFinite(value) || value <= 0) return "-";
    if (value < 3600) return `${Math.max(1, Math.round(value / 60))}m`;
    if (value < 86400) return `${(value / 3600).toFixed(1)}h`;
    return `${(value / 86400).toFixed(1)}d`;
  }

  function toNumber(value) {
    const n = Number(value || 0);
    return Number.isFinite(n) ? n : 0;
  }

  function normalizeChangeHistory(value) {
    if (!Array.isArray(value)) return [];
    return value
      .map((point) => {
        const pct = Number(point?.change_pct);
        if (!Number.isFinite(pct)) return null;
        return {
          change_pct: pct,
          mcap: toNumber(point?.mcap),
          from_mcap: toNumber(point?.from_mcap),
          ts: toNumber(point?.ts),
          signal_type: String(point?.signal_type || ""),
        };
      })
      .filter(Boolean);
  }

  function renderChangeHistory(history, fallbackText) {
    const items = Array.isArray(history) ? history.slice(-8) : [];
    if (!items.length) return escapeHtml(fallbackText || "-");
    return items
      .map((point) => {
        const pct = toNumber(point.change_pct);
        const cls = pct >= 0 ? "ca-positive" : "ca-negative";
        return `<span class="${cls}">${escapeHtml(fmtSignedPct(pct))}</span>`;
      })
      .join("<i>,</i>");
  }

  function renderTopHoldChanges(item) {
    const groups = [
      ["T10", item.top10_pct_delta],
      ["T20", item.top20_pct_delta],
      ["T50", item.top50_pct_delta],
      ["T100", item.top100_pct_delta],
    ];
    return groups
      .map(([label, value]) => {
        const pct = toNumber(value) * 100;
        const cls = pct >= 0 ? "ca-positive" : "ca-negative";
        return `<small><i>${label}</i><strong class="${cls}">${escapeHtml(fmtSignedPct(pct))}</strong></small>`;
      })
      .join("");
  }

  function calcFirstGainPct(currentMcap, firstMcap) {
    const current = toNumber(currentMcap);
    const first = toNumber(firstMcap);
    if (current <= 0 || first <= 0) return null;
    return ((current - first) / first) * 100;
  }

  function shortCa(ca) {
    return ca ? `${ca.slice(0, 6)}...${ca.slice(-4)}` : "No CA";
  }

  function gmgnUrl(ca, chain = "sol") {
    return ca ? `https://gmgn.ai/${encodeURIComponent(chain || "sol")}/token/${encodeURIComponent(ca)}` : "https://gmgn.ai/";
  }

  function walletName(wallet) {
    const label = wallet.label || {};
    const name = label.name ? `${label.name} ` : "";
    return `${name}${wallet.short || shortCa(wallet.address || "")}`;
  }

  function createPanel() {
    const host = document.createElement("div");
    host.className = "ca-cluster-host";
    const panel = document.createElement("div");
    panel.className = "ca-cluster-panel";
    host.appendChild(panel);
    document.documentElement.appendChild(host);
    return panel;
  }

  const panel = createPanel();
  restorePanelLayout();

  function row(label, value) {
    return `<div class="ca-cluster-row"><div class="ca-cluster-label">${escapeHtml(label)}</div><div class="ca-cluster-value">${value}</div></div>`;
  }

  function renderWalletList(wallets, max = 4) {
    if (!wallets || !wallets.length) return L.none;
    return wallets
      .slice(0, max)
      .map((wallet) => `${escapeHtml(walletName(wallet))} ${fmtPct(wallet.hold_pct || 0)} / ${fmtSignedPct(wallet.profit_pct)}`)
      .join("<br>");
  }

  function renderClusterList(clusters, emptyText) {
    if (!clusters || !clusters.length) return `<div class="ca-cluster-empty">${emptyText}</div>`;
    return `<div class="ca-cluster-list">${clusters
      .map(
        (cluster) => `<div class="ca-cluster-item">
          <div class="ca-cluster-item-head">
            <span>${escapeHtml(cluster.bucket_label || cluster.label || "")}</span>
            <span>${cluster.count || 0} ${L.wallet}</span>
          </div>
          <div class="ca-cluster-wallets">${renderWalletList(cluster.wallets || [])}</div>
        </div>`,
      )
      .join("")}</div>`;
  }

  function renderWalletCards(wallets) {
    if (!wallets || !wallets.length) return `<div class="ca-cluster-empty">${L.noBundlers}</div>`;
    return `<div class="ca-cluster-list">${wallets
      .slice(0, 20)
      .map((wallet) => {
        const groups = ((wallet.label || {}).groups || []).map((item) => `<span class="ca-cluster-chip">${escapeHtml(String(item))}</span>`).join("");
        const tags = [...(wallet.tags || []), ...(wallet.maker_tags || [])]
          .slice(0, 4)
          .map((item) => `<span class="ca-cluster-chip">${escapeHtml(String(item))}</span>`)
          .join("");
        return `<div class="ca-cluster-item">
          <div class="ca-cluster-item-head">
            <span>${escapeHtml(walletName(wallet))}</span>
            <span>${fmtPct(wallet.hold_pct)}</span>
          </div>
          <div class="ca-cluster-wallet-line">
            <code>${escapeHtml(wallet.address || "")}</code>
            <button class="ca-copy-button" data-copy="${escapeAttr(wallet.address || "")}">${STATE.copied === wallet.address ? L.copied : L.copy}</button>
          </div>
          <div class="ca-cluster-meta">
            ${L.buy} ${fmtUsd(wallet.buy_volume)} / ${L.holding} ${fmtUsd(wallet.usd_value)} / ${L.sold} ${fmtPct(wallet.sold_pct)} / ${L.profit} ${fmtSignedPct(wallet.profit_pct)}
            <br>${L.realized} ${fmtUsd(wallet.realized_profit)} / ${L.unrealized} ${fmtUsd(wallet.unrealized_profit)}
          </div>
          <div>${groups}${tags}</div>
        </div>`;
      })
      .join("")}</div>`;
  }

  function renderSummaryCards(items) {
    if (!items || !items.length) return `<div class="ca-cluster-empty">${L.noSummary}</div>`;
    return `<div class="ca-summary-grid">${items
      .slice(0, 10)
      .map(
        (item) => `<details class="ca-summary-card">
          <summary>
            <span>${escapeHtml(item.name || "")}</span>
            <b>${fmtPct(item.wallet_pct)} / ${fmtSignedPct(item.avg_profit_pct)}</b>
          </summary>
          <div class="ca-summary-metrics">
            ${row(L.walletCount, `${item.count || 0}`)}
            ${row(L.holdPct, fmtPct(item.hold_pct))}
            ${item.sell_volume === undefined ? row(L.buyVolume, fmtUsd(item.buy_volume)) : ""}
            ${row(L.profitable, fmtPct(item.profitable_pct))}
            ${item.bottom_seller_count !== undefined ? row(L.highSell, `${item.bottom_seller_count || 0}`) : ""}
            ${item.sell_progress_pct !== undefined ? row(L.sellProgress, fmtPct(item.sell_progress_pct)) : ""}
            ${item.remaining_usd !== undefined ? row(L.remainingHolding, fmtUsd(item.remaining_usd)) : ""}
            ${item.profit !== undefined ? row(L.profit, `${fmtUsd(item.profit)} / ${fmtSignedPct(item.avg_profit_pct)}`) : ""}
            ${item.sell_volume !== undefined ? row("\u4e70/\u5356/\u51c0", `${fmtUsd(item.buy_volume)} / ${fmtUsd(item.sell_volume)} / ${fmtUsd(item.net_volume)}`) : ""}
            ${row(L.realized, fmtUsd(item.realized_profit))}
            ${row(L.unrealized, fmtUsd(item.unrealized_profit))}
          </div>
          ${renderWalletCards(item.wallets || [])}
        </details>`,
      )
      .join("")}</div>`;
  }

  function bottomChipSummaryItem(data, totalWallets) {
    if (!data || !data.bottom_wallet_count) return null;
    const wallets = data.wallets || [];
    const profitValues = wallets.map((wallet) => toNumber(wallet.profit_pct)).filter((value) => Number.isFinite(value));
    return {
      name: L.bottomChipTitle,
      count: data.bottom_wallet_count || 0,
      wallet_pct: (toNumber(data.bottom_wallet_count) / Math.max(toNumber(totalWallets), 1)) * 100,
      hold_pct: data.hold_pct,
      buy_volume: data.buy_volume,
      profitable_pct: profitValues.length ? (profitValues.filter((value) => value > 0).length / profitValues.length) * 100 : 0,
      avg_profit_pct: data.profit_pct,
      profit: data.profit,
      realized_profit: data.realized_profit,
      unrealized_profit: data.unrealized_profit,
      bottom_seller_count: data.bottom_seller_count,
      sell_progress_pct: data.sell_progress_pct,
      remaining_usd: data.remaining_usd,
      sell_volume: data.sell_volume,
      net_volume: data.net_volume,
      wallets,
    };
  }

  function renderDetails(title, content, open = false) {
    return `<details class="ca-detail-block"${open ? " open" : ""}>
      <summary>${escapeHtml(title)}</summary>
      <div class="ca-detail-content">${content}</div>
    </details>`;
  }

  function renderResult(result) {
    const token = result.token || {};
    const chip = result.chip_distribution || {};
    const known = result.known_bundled_wallets || [];
    const bundleTime = result.bundle_time_clusters || {};
    const purchaseTime = result.purchase_time_clusters || {};
    const risks = result.risk_factors || [];
    const baseSummaries = result.bundle_category_summary || [];
    const behavior = ((result.holder_trader_structure || {}).behavior || {});
    const bottomChip = result.bottom_chip_sell || {};
    const bottomSummary = bottomChipSummaryItem(bottomChip, chip.wallet_rows);
    const summaries = bottomSummary ? [bottomSummary, ...baseSummaries] : baseSummaries;
    const poolRatio = token.pool_mcap_ratio || (Number(token.market_cap || 0) > 0 ? Number(token.liquidity || 0) / Number(token.market_cap || 0) : 0);

    return `
      ${row(L.token, `${escapeHtml(token.symbol || token.name || "?")} ${escapeHtml(shortCa(result.address))}`)}
      ${row(L.mcapLp, `${fmtUsd(token.market_cap)} / ${fmtUsd(token.liquidity)}`)}
      ${row(L.poolMcapRatio, renderPoolMcapRatio(poolRatio))}
      ${row(L.chips, `Top10 ${fmtPct(chip.top10_pct)} / Top30 ${fmtPct(chip.top30_pct)} / Top50 ${fmtPct(chip.top50_pct)}`)}
      ${row("Top30", `${fmtUsd(chip.top30_profit)} (${L.realized} ${fmtUsd(chip.top30_realized_profit)} / ${L.unrealized} ${fmtUsd(chip.top30_unrealized_profit)})`)}
      ${row("Top50", `${fmtUsd(chip.top50_profit)} (${L.realized} ${fmtUsd(chip.top50_realized_profit)} / ${L.unrealized} ${fmtUsd(chip.top50_unrealized_profit)})`)}
      ${row(L.unsold, `${behavior.zero_sell || 0} ${L.wallet} / ${fmtPct(behavior.zero_sell_pct)}`)}
      <div class="ca-cluster-section">
        <h3>${L.summaryTitle}</h3>
        ${renderSummaryCards(summaries)}
      </div>
      ${renderDetails(L.walletDetails, renderWalletCards(known))}
      ${renderDetails(
        L.bundleTimeDetails,
        `${renderClusterList(bundleTime.same_second_clusters, L.noCreateSecond)}
        <div style="height: 7px"></div>
        ${renderClusterList(bundleTime.hour_clusters, L.noCreateHour)}`,
      )}
      ${renderDetails(
        L.buyTimeDetails,
        `${renderClusterList(purchaseTime.same_second_clusters, L.noBuySecond)}
        <div style="height: 7px"></div>
        ${renderClusterList(purchaseTime.five_minute_clusters, L.noBuyFive)}`,
      )}
      <div class="ca-cluster-section">
        <h3>${L.riskTitle}</h3>
        ${
          risks.length
            ? risks.map((item) => `<span class="ca-cluster-chip">${escapeHtml(String(item))}</span>`).join("")
            : `<div class="ca-cluster-empty">${L.noRisk}</div>`
        }
      </div>
    `;
  }

  function renderAbnormalHead() {
    return `<div class="ca-abnormal-head">
      <div>
        <h3>${L.abnormalTitle}</h3>
        <p>${L.abnormalHint}</p>
      </div>
    </div>`;
  }

  function renderAbnormalContent() {
    if (STATE.abnormalLoading && !STATE.abnormalItems.length) {
      return `<div class="ca-cluster-loading">${L.analyzing} ${L.abnormalView}</div>`;
    }
    if (STATE.abnormalError) {
      return `<div class="ca-cluster-error">${escapeHtml(STATE.abnormalError)}</div>`;
    }
    const items = STATE.abnormalItems || [];
    if (!items.length) {
      return `<div class="ca-cluster-empty">${L.abnormalEmpty}</div>`;
    }
    return `<div class="ca-abnormal-list">
        ${items
          .slice(0, 60)
          .map((item) => {
            const ca = String(item.ca || "");
            const symbol = item.symbol || item.token_type || "?";
            const narrative = item.narrative || item.abnormal_rule || item.source || "";
            const isLowWatchlist = Boolean(item.watchlist_low_mcap_highlight);
            const firstGainPct = calcFirstGainPct(item.current_mcap, item.first_abnormal_mcap);
            const rowClass = `ca-abnormal-row${isLowWatchlist ? " ca-abnormal-row-priority" : ""}`;
            const watchlistBadge = isLowWatchlist
              ? `<span class="ca-priority-badge">${L.watchlistLowMcap} ${fmtUsd(item.watchlist_current_mcap)}</span>`
              : "";
            const riskTags = Array.isArray(item.risk_tags) ? item.risk_tags : [];
            const narrativeCategory = item.narrative_category || "";
            const TAG_STYLES = {
              "\u77ac\u7206": "background:#92400e;color:#fbbf24;border:1px solid #b45309",
              "\u5929\u82b1\u677f": "background:#7f1d1d;color:#fca5a5;border:1px solid #991b1b",
              "\u5927\u5e02\u503c": "background:#4c1d95;color:#c4b5fd;border:1px solid #6d28d9",
              "\u65e0\u91cf": "background:#334155;color:#94a3b8;border:1px solid #475569",
              "\u9ec4\u91d1\u533a\u95f4": "background:#064e3b;color:#34d399;border:1px solid #065f46",
            };
            const riskTagsHtml = riskTags.map(t => {
              const style = TAG_STYLES[t] || "background:#1e293b;color:#94a3b8";
              return `<span class="ca-risk-tag" style="${style}">${t}</span>`;
            }).join("");
            const strategyProfile = item.strategy_profile || "";
            const strategyAction = item.strategy_action || "";
            const strategyWatch = [item.entry_watch_zone ? `\u56de\u8c03${item.entry_watch_zone}` : "", item.hard_risk_line ? `\u98ce\u9669\u7ebf${item.hard_risk_line}` : "", item.hold_watch_window || ""]
              .filter(Boolean)
              .join(" / ");
            const avoidText = Array.isArray(item.avoid_reasons) && item.avoid_reasons.length ? item.avoid_reasons.join("\uff1b") : "";
            return `<div class="${rowClass}">
              <div class="ca-abnormal-token">
                <button class="ca-watch-ca" data-ca="${escapeAttr(ca)}" title="${L.copy}">
                  <b>${escapeHtml(symbol)}</b>
                  <span>${escapeHtml(shortCa(ca))}</span>
                </button>
                ${watchlistBadge}
                ${narrativeCategory ? `<span class="ca-narrative-category">${escapeHtml(narrativeCategory)}</span>` : ""}
                ${riskTagsHtml}
                <button class="ca-copy-button ca-copy-ca-button" data-copy="${escapeAttr(ca)}" title="${L.copyCa}">
                  ${STATE.copied === ca ? L.copied : L.copyCa}
                </button>
                <button class="ca-dismiss-button" data-source="bottom_abnormal" data-ca="${escapeAttr(ca)}" data-id="${escapeAttr(item.id)}" title="${L.dismiss}">X</button>
              </div>
              <div class="ca-watch-note" title="${escapeAttr(narrative)}">${escapeHtml(narrative)}</div>
              <div class="ca-abnormal-metrics">
                <span><em>${L.signalType}</em><b>${escapeHtml(item.signal_label || item.signal_type || "-")}</b></span>
                ${strategyProfile ? `<span class="ca-strategy-metric"><em>${L.strategyProfile}</em><b>${escapeHtml(strategyProfile)} \u00b7 ${escapeHtml(strategyAction)}</b></span>` : ""}
                ${strategyWatch ? `<span class="ca-strategy-metric"><em>${L.strategyWatch}</em><b>${escapeHtml(strategyWatch)}</b></span>` : ""}
                ${avoidText ? `<span class="ca-strategy-metric"><em>${L.avoidReason}</em><b class="ca-negative">${escapeHtml(avoidText)}</b></span>` : ""}
                ${narrativeCategory ? `<span><em>${L.narrativeCategory}</em><b>${escapeHtml(narrativeCategory)}</b></span>` : ""}
                <span><em>${L.currentMcap}</em><b>${fmtUsd(item.current_mcap)}</b></span>
                ${isLowWatchlist ? `<span><em>${L.watchlistMcap}</em><b class="ca-priority-text">${fmtUsd(item.watchlist_current_mcap)}</b></span>` : ""}
                <span><em>${L.firstAbnormalMcap}</em><b>${fmtUsd(item.first_abnormal_mcap)}</b></span>
                <span><em>${L.firstAbnormalTime}</em><b>${escapeHtml(fmtTime(item.first_abnormal_ts))}</b></span>
                <span><em>${L.firstGain}</em><b class="${firstGainPct === null || firstGainPct >= 0 ? "ca-positive" : "ca-negative"}">${firstGainPct === null ? "-" : fmtSignedPct(firstGainPct)}</b></span>
                <span><em>${L.priceChange}</em><b class="${toNumber(item.price_change_pct) >= 0 ? "ca-positive" : "ca-negative"}">${fmtSignedPct(item.price_change_pct)}</b></span>
                <span class="ca-history-metric"><em>${L.abnormalHistory}</em><b class="ca-history-changes">${renderChangeHistory(item.abnormal_mcap_change_history, item.abnormal_mcap_change_text)}</b></span>
                <span class="ca-top-hold-metric"><em>${L.topHoldChange}</em><b>${renderTopHoldChanges(item)}</b></span>
                <span><em>${L.tokenAge}</em><b>${escapeHtml(fmtAge(item.age_sec))}</b></span>
                <span><em>${L.maxMcap}</em><b>${fmtUsd(item.max_mcap || item.ath_mcap || item.peak_mcap)}</b></span>
                <span><em>${L.liquidity}</em><b>${fmtUsd(item.liquidity)}</b></span>
                <span class="ca-pool-metric"><em>${L.poolMcapRatio}</em><b>${renderPoolMcapRatio(item.pool_mcap_ratio)}</b></span>
                <span><em>${L.updated}</em><b>${escapeHtml(fmtTime(item.ts || item.last_seen_at || item.added_at))}</b></span>
              </div>
            </div>`;
          })
          .join("")}
      </div>`;
  }

  function renderAlphaHead() {
    return `<div class="ca-abnormal-head">
      <div>
        <h3>${L.newTokenTitle}</h3>
        <p>${L.newTokenHint}</p>
      </div>
      <button class="ca-cluster-button ca-alpha-refresh" title="${L.refresh}">${L.refresh}</button>
    </div>`;
  }

  function renderAlphaContent() {
    if (STATE.alphaLoading && !STATE.alphaItems.length) {
      return `<div class="ca-cluster-loading">${L.analyzing} ${L.newTokenView}</div>`;
    }
    if (STATE.alphaError) {
      return `<div class="ca-cluster-error">${escapeHtml(STATE.alphaError)}</div>`;
    }
    const items = STATE.alphaItems || [];
    if (!items.length) {
      return `<div class="ca-cluster-empty">${L.newTokenEmpty}</div>`;
    }
    return `<div class="ca-abnormal-list">
      ${items.slice(0, 80).map((item) => {
        const ca = String(item.ca || "");
        const symbol = item.symbol || "UNKNOWN";
        const narrative = item.narrative || item.verdict || item.market_structure || "";
        const repeatBadge = item.repeat_alert ? `<span class="ca-risk-tag ca-alpha-repeat">${L.repeat} #${toNumber(item.alert_no) || 1}</span>` : "";
        return `<div class="ca-abnormal-row ca-alpha-row">
          <div class="ca-abnormal-token">
            <button class="ca-watch-ca" data-ca="${escapeAttr(ca)}" title="${L.copy}">
              <b>${escapeHtml(symbol)}</b>
              <span>${escapeHtml(shortCa(ca))}</span>
            </button>
            ${repeatBadge}
            <button class="ca-copy-button ca-copy-ca-button" data-copy="${escapeAttr(ca)}" title="${L.copyCa}">
              ${STATE.copied === ca ? L.copied : L.copyCa}
            </button>
            <button class="ca-dismiss-button" data-source="alpha_new_tokens" data-ca="${escapeAttr(ca)}" data-id="${escapeAttr(item.id)}" title="${L.dismiss}">X</button>
          </div>
          <div class="ca-watch-note" title="${escapeAttr(narrative)}">${escapeHtml(narrative || "-")}</div>
          <div class="ca-abnormal-metrics">
            <span><em>${L.currentMcap}</em><b>${fmtUsd(item.mcap)}</b></span>
            <span><em>${L.priceChange}</em><b class="${toNumber(item.price_observation_change_pct) >= 0 ? "ca-positive" : "ca-negative"}">${fmtSignedPct(item.price_observation_change_pct)}</b></span>
            <span><em>${L.feeSol}</em><b>${toNumber(item.fee_sol).toFixed(2)} SOL</b></span>
            <span><em>${L.buyScore}</em><b>${toNumber(item.buy_score).toFixed(0)}</b></span>
            <span><em>${L.liquidity}</em><b>${fmtUsd(item.pool_liquidity)}</b></span>
            <span><em>${L.poolMcapRatio}</em><b>${renderPoolMcapRatio(item.pool_mcap_ratio)}</b></span>
            <span><em>${L.tokenAge}</em><b>${escapeHtml(item.created_time || "-")}</b></span>
            <span><em>${L.signalType}</em><b>${escapeHtml(item.repeat_alert_type || item.verdict || "-")}</b></span>
            <span><em>${L.pushTime}</em><b>${escapeHtml(fmtTime(item.ts))}</b></span>
          </div>
        </div>`;
      }).join("")}
    </div>`;
  }

  function renderWatchView() {
    const isAlpha = STATE.view === "alpha";
    return `<div class="ca-watch-grid">
      <div class="ca-bottom-tabs">
        <button class="ca-view-button ${!isAlpha ? "is-active" : ""}" data-view="abnormal">${L.abnormalTitle}</button>
        <button class="ca-view-button ${isAlpha ? "is-active" : ""}" data-view="alpha">${L.newTokenView}</button>
      </div>
      <section class="ca-watch-section">
        ${isAlpha ? renderAlphaHead() : renderAbnormalHead()}
        <div class="ca-abnormal-content">${isAlpha ? renderAlphaContent() : renderAbnormalContent()}</div>
      </section>
    </div>`;
  }

  function updateAbnormalContent() {
    const container = panel.querySelector(".ca-abnormal-content");
    if (STATE.view !== "abnormal" || !container) return false;
    const scrollTop = container.scrollTop;
    container.innerHTML = renderAbnormalContent();
    attachAbnormalRowHandlers();
    attachCopyHandlers();
    attachDismissHandlers();
    container.scrollTop = scrollTop;
    return true;
  }

  function updateAlphaContent() {
    const container = panel.querySelector(".ca-abnormal-content");
    if (STATE.view !== "alpha" || !container) return false;
    const scrollTop = container.scrollTop;
    container.innerHTML = renderAlphaContent();
    attachAbnormalRowHandlers();
    attachCopyHandlers();
    attachDismissHandlers();
    container.scrollTop = scrollTop;
    return true;
  }

  function render() {
    panel.className = `ca-cluster-panel${STATE.collapsed ? " ca-collapsed" : ""} ca-watch-mode`;

    panel.innerHTML = `
      <div class="ca-cluster-header">
        <div class="ca-cluster-title">${L.watchView}</div>
        <div class="ca-cluster-actions">
          <button class="ca-cluster-button ca-cluster-toggle" title="${L.collapse}">${STATE.collapsed ? "+" : "-"}</button>
        </div>
      </div>
      <div class="ca-cluster-body">
        ${renderWatchView()}
      </div>
      <div class="ca-resize-handle" title="Resize"></div>
    `;

    panel.querySelector(".ca-cluster-toggle")?.addEventListener("click", () => {
      STATE.collapsed = !STATE.collapsed;
      render();
    });
    attachDragHandlers();
    attachResizeHandlers();
    attachViewTabHandlers();
    attachAbnormalRowHandlers();
    attachCopyHandlers();
    attachDismissHandlers();
    attachAlphaRefreshHandler();
    startPluginEventStream();
    if (STATE.view === "alpha" && !STATE.alphaItems.length && !STATE.alphaLoading) {
      loadAlphaNewTokens(false);
    } else if (!STATE.abnormalItems.length && !STATE.abnormalLoading) {
      loadBottomWatchlist(false);
    }
  }

  function attachViewTabHandlers() {
    panel.querySelectorAll(".ca-view-button").forEach((button) => {
      if (button.dataset.viewReady === "1") return;
      button.dataset.viewReady = "1";
      button.addEventListener("click", (event) => {
        event.preventDefault();
        const view = button.getAttribute("data-view") || "abnormal";
        if (STATE.view === view) return;
        STATE.view = view;
        render();
      });
    });
  }

  function attachAlphaRefreshHandler() {
    panel.querySelector(".ca-alpha-refresh")?.addEventListener("click", () => loadAlphaNewTokens(true));
  }

  function attachCopyHandlers() {
    panel.querySelectorAll(".ca-copy-button").forEach((button) => {
      if (button.dataset.copyReady === "1") return;
      button.dataset.copyReady = "1";
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        copyText(button.getAttribute("data-copy") || "");
      });
    });
  }

  function attachAbnormalRowHandlers() {
    panel.querySelectorAll(".ca-watch-ca").forEach((button) => {
      if (button.dataset.caReady === "1") return;
      button.dataset.caReady = "1";
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        const ca = button.getAttribute("data-ca") || "";
        if (!ca) return;
        STATE.ca = ca;
        copyText(ca, false);
      });
    });
  }

  function attachDismissHandlers() {
    panel.querySelectorAll(".ca-dismiss-button").forEach((button) => {
      if (button.dataset.dismissReady === "1") return;
      button.dataset.dismissReady = "1";
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        dismissSignal(
          button.getAttribute("data-source") || "",
          button.getAttribute("data-ca") || "",
          button.getAttribute("data-id") || "",
        );
      });
    });
  }

  function dismissedSignalKey(source, ca) {
    return `${source || ""}:${ca || ""}`;
  }

  function isSignalDismissed(item, source) {
    return Boolean(item && item.ca && item.id && STATE.dismissedSignals[dismissedSignalKey(source, item.ca)] === item.id);
  }

  function compareSignalsDesc(a, b) {
    const tsDiff = ((b && b.ts) || 0) - ((a && a.ts) || 0);
    if (tsDiff !== 0) return tsDiff;
    return String((b && b.id) || "").localeCompare(String((a && a.id) || ""));
  }

  function dismissSignal(source, ca, id) {
    if (!source || !ca || !id) return;
    STATE.dismissedSignals[dismissedSignalKey(source, ca)] = id;
    if (source === "bottom_abnormal") {
      STATE.abnormalItems = STATE.abnormalItems.filter((item) => !(item.ca === ca && item.id === id));
      updateAbnormalContent();
      return;
    }
    if (source === "alpha_new_tokens") {
      STATE.alphaItems = STATE.alphaItems.filter((item) => !(item.ca === ca && item.id === id));
      updateAlphaContent();
      return;
    }
  }

  async function analyze(ca, force) {
    if (!ca || ca.length < 32) {
      STATE.error = L.noValidCa;
      STATE.result = null;
      render();
      return;
    }
    if (!force && ca === STATE.ca && STATE.result) return;
    STATE.ca = ca;
    STATE.loading = true;
    STATE.error = "";
    render();
    try {
      const message = { type: "ANALYZE_CA", address: ca, chain: "sol", limit: 100 };
      const response = await chrome.runtime.sendMessage(message);
      if (!response || !response.ok) {
        throw new Error((response && response.error) || "No response from extension background worker.");
      }
      STATE.serviceMode = response.mode || STATE.serviceMode;
      STATE.serviceBaseUrl = response.baseUrl || STATE.serviceBaseUrl;
      STATE.result = response.data;
    } catch (err) {
      STATE.result = null;
      STATE.error = `${L.apiError}: ${err.message || err}`;
    } finally {
      STATE.loading = false;
      render();
    }
  }

  function normalizeBottomAbnormal(item) {
    if (!item || item.source !== "bottom_abnormal") return null;
    const extra = item.extra || {};
    const signalType = String(extra.signal_type || "");
    if (signalType === "watch") return null;
    const ca = String(extra.address || item.ca || "").trim();
    if (!ca) return null;
    const currentMcap = toNumber(extra.current_mcap);
    const athMcap = toNumber(extra.ath_mcap);
    const changeHistory = normalizeChangeHistory(extra.abnormal_mcap_change_history);
    const firstHistoryPoint = changeHistory[0] || {};
    const firstAbnormalMcap = toNumber(extra.first_signal_mcap) || toNumber(firstHistoryPoint.mcap);
    const firstAbnormalTs = toNumber(extra.first_signal_ts) || toNumber(firstHistoryPoint.ts);
    const maxMcap = Math.max(
      currentMcap,
      athMcap,
      toNumber(extra.max_abnormal_mcap),
      toNumber(extra.first_signal_mcap),
    );
    return {
      id: item.id || `${ca}:${item.ts || ""}`,
      ca,
      ts: toNumber(item.ts),
      symbol: extra.symbol || item.title || "UNKNOWN",
      source: item.source || "",
      status: item.status || "",
      signal_type: signalType,
      signal_label: extra.signal_label || `${signalType}`,
      strategy_profile: extra.strategy_profile || "",
      strategy_action: extra.strategy_action || "",
      entry_watch_zone: extra.entry_watch_zone || "",
      hard_risk_line: extra.hard_risk_line || "",
      hold_watch_window: extra.hold_watch_window || "",
      fast_peak_rule: extra.fast_peak_rule || "",
      avoid_reasons: Array.isArray(extra.avoid_reasons) ? extra.avoid_reasons : [],
      abnormal_rule: extra.abnormal_rule || "",
      narrative: extra.narrative || extra.narrative_desc || item.text || "",
      narrative_category: extra.narrative_category || "",
      narrative_type: extra.narrative_type || "",
      current_mcap: currentMcap,
      first_abnormal_mcap: firstAbnormalMcap,
      first_abnormal_ts: firstAbnormalTs,
      max_mcap: maxMcap,
      ath_mcap: athMcap,
      liquidity: toNumber(extra.pool_total_liquidity || extra.pool_liquidity),
      price_change_pct: toNumber(extra.price_change_pct),
      abnormal_mcap_change_history: changeHistory,
      abnormal_mcap_change_text: extra.abnormal_mcap_change_text || "",
      abnormal_signal_count: toNumber(extra.abnormal_signal_count),
      age_sec: toNumber(extra.age_sec),
      pool_mcap_ratio: toNumber(extra.pool_mcap_ratio),
      top10_pct_delta: toNumber(extra.top10_pct_delta),
      top10_current_pct: toNumber(extra.top10_current_pct),
      top10_previous_pct: toNumber(extra.top10_previous_pct),
      top20_pct_delta: toNumber(extra.top20_pct_delta),
      top20_current_pct: toNumber(extra.top20_current_pct),
      top20_previous_pct: toNumber(extra.top20_previous_pct),
      top50_pct_delta: toNumber(extra.top50_pct_delta),
      top50_current_pct: toNumber(extra.top50_current_pct),
      top50_previous_pct: toNumber(extra.top50_previous_pct),
      top100_pct_delta: toNumber(extra.top100_pct_delta),
      top100_current_pct: toNumber(extra.top100_current_pct),
      top100_previous_pct: toNumber(extra.top100_previous_pct),
      in_bottom_watchlist: Boolean(extra.in_bottom_watchlist),
      watchlist_current_mcap: toNumber(extra.watchlist_current_mcap),
      watchlist_low_mcap_threshold: toNumber(extra.watchlist_low_mcap_threshold),
      watchlist_low_mcap_highlight: Boolean(extra.watchlist_low_mcap_highlight),
      risk_tags: Array.isArray(extra.risk_tags) ? extra.risk_tags : [],
    };
  }

  function normalizeAlphaNewToken(item) {
    if (!item) return null;
    const extra = item.extra || {};
    const ca = String(item.address || extra.address || item.ca || "").trim();
    if (!ca) return null;
    return {
      id: String(item.id || `${ca}:${item.ts || ""}`),
      ca,
      ts: toNumber(item.ts || extra.ts),
      symbol: item.symbol || extra.symbol || "UNKNOWN",
      mcap: toNumber(item.entry_mcap || extra.entry_mcap),
      price: toNumber(item.entry_price || extra.entry_price),
      holder_count: toNumber(item.holder_count || extra.holder_count),
      fee_sol: toNumber(item.fee_sol || extra.fee_sol),
      buy_score: toNumber(item.buy_score || extra.buy_score),
      pool_liquidity: toNumber(item.pool_liquidity || extra.pool_liquidity),
      pool_mcap_ratio: toNumber(item.pool_mcap_ratio || extra.pool_mcap_ratio),
      price_observation_change_pct: toNumber(item.price_observation_change_pct || extra.price_observation_change_pct),
      alert_no: toNumber(item.alert_no || extra.alert_no),
      repeat_alert: Boolean(item.repeat_alert || extra.repeat_alert),
      repeat_alert_type: item.repeat_alert_type || extra.repeat_alert_type || "",
      narrative: item.narrative || extra.narrative || "",
      verdict: item.verdict || extra.verdict || "",
      market_structure: item.market_structure || extra.market_structure || "",
      pool_label: item.pool_label || extra.pool_label || "",
      created_time: item.created_time || extra.created_time || "",
      source: "alpha_new_tokens",
    };
  }

  async function loadBottomWatchlist(force) {
    if (STATE.abnormalLoading) return;
    if (!force && STATE.abnormalItems.length) return;
    const hasRows = STATE.abnormalItems.length > 0;
    const requestId = STATE.abnormalRequestId + 1;
    STATE.abnormalRequestId = requestId;
    STATE.abnormalLoading = true;
    STATE.abnormalError = "";
    if (!hasRows) {
      if (!updateAbnormalContent()) render();
    }
    try {
      const response = await chrome.runtime.sendMessage({ type: "GET_BOTTOM_ABNORMAL", limit: 100 });
      if (requestId !== STATE.abnormalRequestId) return;
      if (!response || !response.ok) {
        throw new Error((response && response.error) || "No response from extension background worker.");
      }
      STATE.serviceMode = response.mode || STATE.serviceMode;
      STATE.serviceBaseUrl = response.baseUrl || STATE.serviceBaseUrl;
      const seen = new Set();
      STATE.abnormalItems = (Array.isArray(response.data?.items) ? response.data.items : [])
        .map(normalizeBottomAbnormal)
        .sort(compareSignalsDesc)
        .filter((item) => {
          if (!item || seen.has(item.ca)) return false;
          seen.add(item.ca);
          if (isSignalDismissed(item, "bottom_abnormal")) return false;
          return true;
        });
      STATE.abnormalLastCount = STATE.abnormalItems.length;
    } catch (err) {
      if (requestId !== STATE.abnormalRequestId) return;
      if (!hasRows) STATE.abnormalItems = [];
      STATE.abnormalError = `${L.apiError}: ${err.message || err}`;
    } finally {
      if (requestId !== STATE.abnormalRequestId) return;
      STATE.abnormalLoading = false;
      if (!updateAbnormalContent()) render();
    }
  }

  async function loadAlphaNewTokens(force) {
    if (STATE.alphaLoading) return;
    if (!force && STATE.alphaItems.length) return;
    const hasRows = STATE.alphaItems.length > 0;
    const requestId = STATE.alphaRequestId + 1;
    STATE.alphaRequestId = requestId;
    STATE.alphaLoading = true;
    STATE.alphaError = "";
    if (!hasRows) {
      if (!updateAlphaContent()) render();
    }
    try {
      const response = await chrome.runtime.sendMessage({ type: "GET_ALPHA_NEW_TOKENS", limit: 100 });
      if (requestId !== STATE.alphaRequestId) return;
      if (!response || !response.ok) {
        throw new Error((response && response.error) || "No response from extension background worker.");
      }
      STATE.serviceMode = response.mode || STATE.serviceMode;
      STATE.serviceBaseUrl = response.baseUrl || STATE.serviceBaseUrl;
      const seen = new Set();
      STATE.alphaItems = (Array.isArray(response.data?.items) ? response.data.items : [])
        .map(normalizeAlphaNewToken)
        .sort(compareSignalsDesc)
        .filter((item) => {
          if (!item || seen.has(item.ca)) return false;
          seen.add(item.ca);
          if (isSignalDismissed(item, "alpha_new_tokens")) return false;
          return true;
        });
    } catch (err) {
      if (requestId !== STATE.alphaRequestId) return;
      if (!hasRows) STATE.alphaItems = [];
      STATE.alphaError = `${L.apiError}: ${err.message || err}`;
    } finally {
      if (requestId !== STATE.alphaRequestId) return;
      STATE.alphaLoading = false;
      if (!updateAlphaContent()) render();
    }
  }

  function startAbnormalAutoRefresh() {
    if (STATE.abnormalTimer) return;
    STATE.abnormalTimer = window.setInterval(() => {
      if (STATE.view === "abnormal" && !STATE.abnormalLoading) {
        loadBottomWatchlist(true);
      }
    }, 10000);
  }

  function stopAbnormalAutoRefresh() {
    if (!STATE.abnormalTimer) return;
    window.clearInterval(STATE.abnormalTimer);
    STATE.abnormalTimer = 0;
  }

  function startAlphaAutoRefresh() {
    if (STATE.alphaTimer) return;
    STATE.alphaTimer = window.setInterval(() => {
      if (STATE.view === "alpha" && !STATE.alphaLoading) {
        loadAlphaNewTokens(true);
      }
    }, 10000);
  }

  function stopAlphaAutoRefresh() {
    if (!STATE.alphaTimer) return;
    window.clearInterval(STATE.alphaTimer);
    STATE.alphaTimer = 0;
  }

  function upsertByCa(items, item) {
    if (!item || !item.ca) return items;
    const next = items.filter((existing) => existing.ca !== item.ca);
    next.unshift(item);
    return next.sort(compareSignalsDesc).slice(0, 120);
  }

  function handlePluginSignal(item) {
    if (!item || !item.source) return;
    STATE.pluginEventLastSignalAt = Date.now();
    if (item.id) {
      STATE.pluginEventLastId = String(item.id);
      chrome.storage.local.set({ [PLUGIN_EVENT_LAST_ID_KEY]: STATE.pluginEventLastId }).catch(() => {});
    }
    if (item.source === "bottom_abnormal") {
      const normalized = normalizeBottomAbnormal(item);
      if (!normalized || isSignalDismissed(normalized, "bottom_abnormal")) return;
      STATE.abnormalItems = upsertByCa(STATE.abnormalItems, normalized);
      updateAbnormalContent();
      return;
    }
    if (item.source === "alpha_new_tokens") {
      const normalized = normalizeAlphaNewToken(item);
      if (!normalized || isSignalDismissed(normalized, "alpha_new_tokens")) return;
      STATE.alphaItems = upsertByCa(STATE.alphaItems, normalized);
      updateAlphaContent();
    }
  }

  function schedulePluginEventFallback() {
    if (STATE.pluginEventFallbackTimer) return;
    STATE.pluginEventFallbackTimer = window.setTimeout(() => {
      STATE.pluginEventFallbackTimer = 0;
      if (STATE.pluginEventReady) return;
      loadBottomWatchlist(true);
      loadAlphaNewTokens(true);
      startPluginEventStream();
    }, PLUGIN_EVENT_FALLBACK_MS);
  }

  async function getPluginEventLastId() {
    if (STATE.pluginEventLastId) return STATE.pluginEventLastId;
    try {
      const stored = await chrome.storage.local.get(PLUGIN_EVENT_LAST_ID_KEY);
      STATE.pluginEventLastId = String(stored?.[PLUGIN_EVENT_LAST_ID_KEY] || "");
    } catch {
      STATE.pluginEventLastId = "";
    }
    return STATE.pluginEventLastId;
  }

  async function startPluginEventStream() {
    if (STATE.pluginEventSource) return;
    try {
      const response = await chrome.runtime.sendMessage({ type: "GET_PLUGIN_EVENT_URL" });
      if (!response || !response.ok || !response.url) {
        schedulePluginEventFallback();
        return;
      }
      const lastId = await getPluginEventLastId();
      const separator = response.url.includes("?") ? "&" : "?";
      const streamUrl = lastId ? `${response.url}${separator}last_id=${encodeURIComponent(lastId)}` : response.url;
      const source = new EventSource(streamUrl);
      STATE.pluginEventSource = source;
      source.addEventListener("ready", () => {
        STATE.pluginEventReady = true;
      });
      source.addEventListener("signal", (event) => {
        STATE.pluginEventReady = true;
        try {
          handlePluginSignal(JSON.parse(event.data || "{}"));
        } catch {}
      });
      source.addEventListener("error", () => {
        STATE.pluginEventReady = false;
        if (STATE.pluginEventSource) {
          STATE.pluginEventSource.close();
          STATE.pluginEventSource = null;
        }
        schedulePluginEventFallback();
      });
    } catch {
      STATE.pluginEventReady = false;
      schedulePluginEventFallback();
    }
  }

  async function copyText(text, rerender = true) {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const input = document.createElement("textarea");
      input.value = text;
      document.documentElement.appendChild(input);
      input.select();
      document.execCommand("copy");
      input.remove();
    }
    STATE.copied = text;
    refreshCopiedState(rerender);
    setTimeout(() => {
      if (STATE.copied === text) {
        STATE.copied = "";
        refreshCopiedState(rerender);
      }
    }, 1200);
  }

  function refreshCopiedState(rerender) {
    if (rerender) {
      render();
      return;
    }
    if (!updateAbnormalContent()) updateAlphaContent();
  }

  function clearPanel() {
    STATE.ca = "";
    STATE.result = null;
    STATE.error = "";
    STATE.loading = false;
    STATE.copied = "";
    render();
  }

  async function loadServiceConfig() {
    try {
      const response = await chrome.runtime.sendMessage({ type: "GET_SERVICE_CONFIG" });
      if (response && response.ok) {
        STATE.serviceMode = response.mode || STATE.serviceMode;
        STATE.serviceBaseUrl = response.baseUrl || STATE.serviceBaseUrl;
        render();
        startPluginEventStream();
      }
    } catch {}
  }

  async function toggleServiceMode() {
    const nextMode = STATE.serviceMode === "server" ? "local" : "server";
    try {
      const response = await chrome.runtime.sendMessage({ type: "SET_SERVICE_MODE", mode: nextMode });
      if (response && response.ok) {
        STATE.serviceMode = response.mode || nextMode;
        STATE.serviceBaseUrl = response.baseUrl || "";
        STATE.result = null;
        STATE.error = "";
        render();
        if (STATE.ca) analyze(STATE.ca, true);
      }
    } catch (err) {
      STATE.error = `${L.apiError}: ${err.message || err}`;
      render();
    }
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function escapeAttr(value) {
    return escapeHtml(value).replaceAll("`", "&#96;");
  }

  function restorePanelLayout() {
    try {
      const saved = JSON.parse(localStorage.getItem(LAYOUT_KEY) || localStorage.getItem(POS_KEY) || "null");
      if (saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) {
        applyPanelLayout(
          saved.left,
          saved.top,
          Number.isFinite(saved.width) ? saved.width : DEFAULT_WIDTH,
          Number.isFinite(saved.height) ? saved.height : DEFAULT_HEIGHT,
        );
        return;
      }
    } catch {}
    const left = Math.max(8, window.innerWidth - 354);
    applyPanelLayout(left, 92, DEFAULT_WIDTH, DEFAULT_HEIGHT);
  }

  function applyPanelPosition(left, top) {
    applyPanelLayout(left, top, panel.offsetWidth || DEFAULT_WIDTH, panel.offsetHeight || DEFAULT_HEIGHT);
  }

  function applyPanelLayout(left, top, width, height) {
    const safeWidth = Math.min(Math.max(MIN_WIDTH, width), Math.max(MIN_WIDTH, window.innerWidth - 16));
    const safeHeight = Math.min(Math.max(MIN_HEIGHT, height), Math.max(MIN_HEIGHT, window.innerHeight - 16));
    panel.style.width = `${safeWidth}px`;
    panel.style.height = `${safeHeight}px`;
    panel.style.maxHeight = "none";

    const maxLeft = Math.max(8, window.innerWidth - safeWidth - 8);
    const maxTop = Math.max(8, window.innerHeight - safeHeight - 8);
    const x = Math.min(Math.max(8, left), maxLeft);
    const y = Math.min(Math.max(8, top), maxTop);
    panel.style.left = `${x}px`;
    panel.style.top = `${y}px`;
    panel.style.right = "auto";
  }

  function savePanelLayout() {
    const rect = panel.getBoundingClientRect();
    localStorage.setItem(LAYOUT_KEY, JSON.stringify({ left: rect.left, top: rect.top, width: rect.width, height: rect.height }));
  }

  function attachDragHandlers() {
    const header = panel.querySelector(".ca-cluster-header");
    if (!header || header.dataset.dragReady === "1") return;
    header.dataset.dragReady = "1";
    header.addEventListener("pointerdown", (event) => {
      if (event.target.closest("button")) return;
      const rect = panel.getBoundingClientRect();
      const startX = event.clientX;
      const startY = event.clientY;
      const startLeft = rect.left;
      const startTop = rect.top;
      STATE.dragging = true;
      header.setPointerCapture(event.pointerId);

      const onMove = (moveEvent) => {
        if (!STATE.dragging) return;
        applyPanelPosition(startLeft + moveEvent.clientX - startX, startTop + moveEvent.clientY - startY);
      };
      const onUp = () => {
        STATE.dragging = false;
        savePanelLayout();
        header.removeEventListener("pointermove", onMove);
        header.removeEventListener("pointerup", onUp);
        header.removeEventListener("pointercancel", onUp);
      };

      header.addEventListener("pointermove", onMove);
      header.addEventListener("pointerup", onUp);
      header.addEventListener("pointercancel", onUp);
    });
  }

  function attachResizeHandlers() {
    const handle = panel.querySelector(".ca-resize-handle");
    if (!handle || handle.dataset.resizeReady === "1") return;
    handle.dataset.resizeReady = "1";
    handle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const rect = panel.getBoundingClientRect();
      const startX = event.clientX;
      const startY = event.clientY;
      const startWidth = rect.width;
      const startHeight = rect.height;
      const startLeft = rect.left;
      const startTop = rect.top;
      STATE.resizing = true;
      handle.setPointerCapture(event.pointerId);

      const onMove = (moveEvent) => {
        if (!STATE.resizing) return;
        applyPanelLayout(
          startLeft,
          startTop,
          startWidth + moveEvent.clientX - startX,
          startHeight + moveEvent.clientY - startY,
        );
      };
      const onUp = () => {
        STATE.resizing = false;
        savePanelLayout();
        handle.removeEventListener("pointermove", onMove);
        handle.removeEventListener("pointerup", onUp);
        handle.removeEventListener("pointercancel", onUp);
      };

      handle.addEventListener("pointermove", onMove);
      handle.addEventListener("pointerup", onUp);
      handle.addEventListener("pointercancel", onUp);
    });
  }

  render();
  loadServiceConfig();
})();
